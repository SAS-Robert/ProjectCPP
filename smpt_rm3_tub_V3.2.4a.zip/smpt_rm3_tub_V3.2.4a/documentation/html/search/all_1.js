var searchData=
[
  ['battery_5flevel',['battery_level',['../struct_smpt__get__battery__status__ack.html#a3c0aee7bfb6e464e575c6fe45ebf9b86',1,'Smpt_get_battery_status_ack']]],
  ['battery_5fvoltage',['battery_voltage',['../struct_smpt__get__battery__status__ack.html#a5c46d6bbac70c999144be13eaf84377b',1,'Smpt_get_battery_status_ack']]],
  ['buffer',['buffer',['../struct_packet__input__buffer.html#a56ed84df35de10bdb65e72b184309497',1,'Packet_input_buffer']]],
  ['buffer_5fstate',['buffer_state',['../struct_packet__input__buffer.html#afa47133660798b647f680ee370351e9c',1,'Packet_input_buffer']]]
];
