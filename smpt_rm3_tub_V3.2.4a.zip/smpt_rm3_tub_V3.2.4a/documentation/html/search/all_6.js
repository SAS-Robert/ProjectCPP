var searchData=
[
  ['gain_5fch1',['gain_ch1',['../struct_smpt__dl__init.html#ad4d00cc71ecc3e9d29a9935ce11f0e31',1,'Smpt_dl_init']]],
  ['general',['General',['../general.html',1,'']]],
  ['getting_20started',['Getting started',['../page_started.html',1,'']]]
];
