var searchData=
[
  ['data_2dmeasurement',['Data-measurement',['../data_measurement.html',1,'']]],
  ['data_5fselection',['data_selection',['../struct_smpt__ml__get__current__data.html#a15db8f81d3e05e3b88638210dfacf217',1,'Smpt_ml_get_current_data::data_selection()'],['../struct_smpt__ml__get__current__data__ack.html#a15db8f81d3e05e3b88638210dfacf217',1,'Smpt_ml_get_current_data_ack::data_selection()']]],
  ['demux_5fconfig',['demux_config',['../struct_smpt__ll__channel__config.html#a984032a45dcfd1921e37fcbeebae66f0',1,'Smpt_ll_channel_config']]],
  ['demux_5fid',['demux_id',['../struct_smpt__ll__init__ack.html#a69c58a15ee6075726bdebe585961cfbf',1,'Smpt_ll_init_ack::demux_id()'],['../struct_smpt__ll__demux.html#a3192129b2b8b622322f5e21c1d229bfb',1,'Smpt_ll_demux::demux_id()']]],
  ['demux_5flength',['demux_length',['../struct_smpt__ll__channel__config.html#a5c560dedf749da9c83e67df821ac7d8e',1,'Smpt_ll_channel_config']]],
  ['device_5fid',['device_id',['../struct_smpt__get__device__id__ack.html#a3d5cbabdf9a23614ffe176fdb23bceec',1,'Smpt_get_device_id_ack']]],
  ['do_5fnot_5fsend_5flive_5fdata',['do_not_send_live_data',['../struct_smpt__dm__init.html#a3f7b94cc834cf2389918006f6bd0e2ab',1,'Smpt_dm_init']]],
  ['duration_5fof_5fplanned_5fm',['duration_of_planned_m',['../struct_smpt__dl__init.html#a503bec950fd299dcb681d7dd6e689c9a',1,'Smpt_dl_init']]]
];
