var searchData=
[
  ['sciencemode_20_28version_203_2e2_2e4_29',['ScienceMode (Version 3.2.4)',['../index.html',1,'']]],
  ['stimulation_20information',['Stimulation information',['../test_pulse.html',1,'']]]
];
