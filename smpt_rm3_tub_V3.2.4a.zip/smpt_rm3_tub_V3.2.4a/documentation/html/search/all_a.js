var searchData=
[
  ['library_20changes',['Library changes',['../library_changes.html',1,'']]],
  ['live_5fdata_5fmode_5fflag',['live_data_mode_flag',['../struct_smpt__dl__init.html#ac738417bbc6c9c64ab8381108e36718a',1,'Smpt_dl_init']]],
  ['loff_5fstatn',['loff_statn',['../struct_smpt__dl__ads129x.html#a92ceacf92691351b9021021dd3b132f6',1,'Smpt_dl_ads129x']]],
  ['low_2dlevel_20stimulation',['Low-level stimulation',['../low_level.html',1,'']]],
  ['low_2dlevel_20stimulation_20additional_20definitions_20and_20functions_20comments',['Low-level stimulation additional definitions and functions comments',['../low_level_additional.html',1,'']]],
  ['ls_5fstop',['ls_stop',['../struct_smpt__ll__emg__switches.html#aaa7e2aa4d7ef4ef9c9424bd6be7ecf98',1,'Smpt_ll_emg_switches']]]
];
