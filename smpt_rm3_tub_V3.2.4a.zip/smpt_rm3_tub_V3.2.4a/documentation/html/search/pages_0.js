var searchData=
[
  ['data_2dmeasurement',['Data-measurement',['../data_measurement.html',1,'']]]
];
