var searchData=
[
  ['feature_20overview',['Feature overview',['../feature_overview.html',1,'']]],
  ['firmware_20changes',['Firmware changes',['../firmware_changes.html',1,'']]]
];
