var searchData=
[
  ['ks_5f1_5fduration',['ks_1_duration',['../struct_smpt__ll__emg__switches.html#a8af5e87a323a7b7bc65cc6259ef15add',1,'Smpt_ll_emg_switches']]],
  ['ks_5f1_5fstart',['ks_1_start',['../struct_smpt__ll__emg__switches.html#aa70dca0665c4b5c7e9c89ce82195e07e',1,'Smpt_ll_emg_switches']]],
  ['ks_5f2_5fduration',['ks_2_duration',['../struct_smpt__ll__emg__switches.html#ae8fdcf5645cd02e127946944f055863c',1,'Smpt_ll_emg_switches']]],
  ['ks_5f2_5fstart',['ks_2_start',['../struct_smpt__ll__emg__switches.html#a612cd465296d22d23f4783116a77f764',1,'Smpt_ll_emg_switches']]]
];
