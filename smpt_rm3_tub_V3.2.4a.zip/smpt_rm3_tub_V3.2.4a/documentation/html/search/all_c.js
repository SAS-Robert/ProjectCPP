var searchData=
[
  ['new_5fack_5favailable',['new_ack_available',['../struct_smpt__cmd__list.html#ad1fdf6b170ecbfd48a86720a823c35e6',1,'Smpt_cmd_list']]],
  ['number_5fof_5fchannels',['number_of_channels',['../struct_smpt__dl__init.html#a94a7fde2c97ddc6ee56208efc435ce05',1,'Smpt_dl_init']]],
  ['number_5fof_5fexpected',['number_of_expected',['../struct_smpt__cmd__list.html#adca70e930551d0921731fd78ebbc99b5',1,'Smpt_cmd_list']]],
  ['number_5fof_5fpoints',['number_of_points',['../struct_smpt__ll__channel__config.html#a31c93d350afab0e776a77278f487ae46',1,'Smpt_ll_channel_config::number_of_points()'],['../struct_smpt__ml__channel__config.html#a31c93d350afab0e776a77278f487ae46',1,'Smpt_ml_channel_config::number_of_points()']]],
  ['number_5fof_5frows',['number_of_rows',['../struct_packet__input__buffer.html#ad0e02d845ca7baa0725da6c7bc85186d',1,'Packet_input_buffer']]],
  ['number_5fof_5fsamples',['number_of_samples',['../struct_smpt__dm__slot__init.html#ac53c88ccbb616c9f1a265831f3d3bb2e',1,'Smpt_dm_slot_init::number_of_samples()'],['../struct_smpt__dm__slot.html#ac53c88ccbb616c9f1a265831f3d3bb2e',1,'Smpt_dm_slot::number_of_samples()']]],
  ['number_5fof_5fslots',['number_of_slots',['../struct_smpt__dm__init.html#a97c07c9939fd27a87abd628185d11448',1,'Smpt_dm_init::number_of_slots()'],['../struct_smpt__dm__data.html#a97c07c9939fd27a87abd628185d11448',1,'Smpt_dm_data::number_of_slots()']]]
];
