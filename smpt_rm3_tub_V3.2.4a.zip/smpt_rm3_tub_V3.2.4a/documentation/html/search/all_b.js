var searchData=
[
  ['main_5fstatus',['main_status',['../struct_smpt__get__main__status__ack.html#a9b043617df7dea27f0ce113de0491995',1,'Smpt_get_main_status_ack']]],
  ['major',['major',['../struct_smpt__version.html#a5bd4e4c943762926c8f653b6224cced2',1,'Smpt_version']]],
  ['measurement_5ffile_5fid',['measurement_file_id',['../struct_smpt__dl__init__ack.html#ab41ae0034247c77e436b94cb5def8a3a',1,'Smpt_dl_init_ack']]],
  ['measurement_5fid',['measurement_id',['../struct_smpt__dl__mmi__.html#a85cc19a154b4ccd3c6c8d37792abd5c4',1,'Smpt_dl_mmi_']]],
  ['measurement_5fnumber',['measurement_number',['../struct_smpt__dl__mmi__.html#a2d91eaf885624185866eb2d43efe44cb',1,'Smpt_dl_mmi_']]],
  ['meta_5fdata',['meta_data',['../struct_smpt__dm__init.html#a46643adf59d3fa0945b93a8dcc57f199',1,'Smpt_dm_init']]],
  ['meta_5fdata_5flength',['meta_data_length',['../struct_smpt__dm__init.html#ab501d41c9956f8141739ab5597ba2030',1,'Smpt_dm_init']]],
  ['mid_2dlevel_20stimulation',['Mid-level stimulation',['../mid_level.html',1,'']]],
  ['minor',['minor',['../struct_smpt__version.html#ae2f416b0a34b7beb4ed3873d791ac393',1,'Smpt_version']]],
  ['modify_5fdemux',['modify_demux',['../struct_smpt__ll__channel__config.html#a85e4232f03b9788b61f56298006a2599',1,'Smpt_ll_channel_config']]],
  ['mute_5fflag',['mute_flag',['../struct_smpt__dl__init.html#ab3cc7ed85993c4fd0d15e5fd8d49549b',1,'Smpt_dl_init']]]
];
