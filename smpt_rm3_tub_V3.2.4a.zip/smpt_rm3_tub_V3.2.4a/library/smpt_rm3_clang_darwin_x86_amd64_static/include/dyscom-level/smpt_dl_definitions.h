#ifndef SMPT_DL_DEFINITIONS_H
#define SMPT_DL_DEFINITIONS_H

#include "smpt_dl_definitions_data_types.h"

#endif /* SMPT_DL_DEFINITIONS_H */
